<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';
require_once 'fpdf/fpdf.php';

// Cek login
check_login();

// Ambil data barang
$barang_list = get_all_barang($conn);

// Ambil statistik
$total_barang = hitung_total_barang($conn);
$total_stok = hitung_total_stok($conn);
$total_nilai = hitung_total_nilai($conn);

// Buat PDF
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Header dengan warna navy
$pdf->SetTextColor(30, 58, 95);
$pdf->Cell(0, 10, 'LAPORAN INVENTORY BARANG', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 5, 'Tanggal: ' . date('d-m-Y H:i:s'), 0, 1, 'C');
$pdf->Cell(0, 5, 'Dicetak oleh: ' . $_SESSION['nama_lengkap'], 0, 1, 'C');
$pdf->Ln(5);

// Statistik
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetTextColor(30, 58, 95);
$pdf->Cell(0, 7, 'RINGKASAN', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFillColor(247, 250, 252);
$pdf->Cell(70, 6, 'Total Jumlah Barang', 1, 0, 'L', true);
$pdf->Cell(60, 6, ': ' . number_format($total_barang), 1, 1);
$pdf->Cell(70, 6, 'Total Stok', 1, 0, 'L', true);
$pdf->Cell(60, 6, ': ' . number_format($total_stok), 1, 1);
$pdf->Cell(70, 6, 'Total Nilai Inventory', 1, 0, 'L', true);
$pdf->Cell(60, 6, ': Rp ' . number_format($total_nilai, 0, ',', '.'), 1, 1);
$pdf->Ln(5);

// Tabel Header dengan navy theme
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(30, 58, 95);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(10, 8, 'No', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Kode', 1, 0, 'C', true);
$pdf->Cell(60, 8, 'Nama Barang', 1, 0, 'C', true);
$pdf->Cell(35, 8, 'Kategori', 1, 0, 'C', true);
$pdf->Cell(35, 8, 'Harga', 1, 0, 'C', true);
$pdf->Cell(20, 8, 'Stok', 1, 0, 'C', true);
$pdf->Cell(45, 8, 'Total Nilai', 1, 1, 'C', true);

// Tabel Data
$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(0, 0, 0);

if (count($barang_list) > 0) {
    $fill = false;
    foreach ($barang_list as $index => $barang) {
        $pdf->SetFillColor(247, 250, 252);
        $pdf->Cell(10, 7, $index + 1, 1, 0, 'C', $fill);
        $pdf->Cell(30, 7, $barang['kode'], 1, 0, 'L', $fill);
        $pdf->Cell(60, 7, substr($barang['nama'], 0, 30), 1, 0, 'L', $fill);
        $pdf->Cell(35, 7, $barang['kategori'], 1, 0, 'L', $fill);
        $pdf->Cell(35, 7, 'Rp ' . number_format($barang['harga'], 0, ',', '.'), 1, 0, 'R', $fill);
        $pdf->Cell(20, 7, number_format($barang['stok']), 1, 0, 'C', $fill);
        $pdf->Cell(45, 7, 'Rp ' . number_format($barang['harga'] * $barang['stok'], 0, ',', '.'), 1, 1, 'R', $fill);
        $fill = !$fill;
    }
    
    // Total
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetFillColor(30, 58, 95);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->Cell(170, 7, 'TOTAL', 1, 0, 'R', true);
    $pdf->Cell(20, 7, number_format($total_stok), 1, 0, 'C', true);
    $pdf->Cell(45, 7, 'Rp ' . number_format($total_nilai, 0, ',', '.'), 1, 1, 'R', true);
} else {
    $pdf->Cell(235, 7, 'Belum ada data barang', 1, 1, 'C');
}

// Footer
$pdf->Ln(10);
$pdf->SetFont('Arial', 'I', 8);
$pdf->SetTextColor(74, 85, 104);
$pdf->Cell(0, 5, 'Sistem Inventory Ujian - Junior Web Developer', 0, 1, 'C');

// Output PDF
$pdf->Output('I', 'Laporan_Inventory_' . date('Ymd_His') . '.pdf');
?>
