<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

// Cek login
check_login();

$page_title = 'Data Barang';
$error = '';
$success = '';

// Proses tambah barang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah') {
    if (!validate_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
    } else {
        $result = tambah_barang(
            $conn,
            $_POST['kode'],
            $_POST['nama'],
            $_POST['kategori'],
            $_POST['harga'],
            $_POST['stok']
        );
        
        if ($result['success']) {
            $success = $result['message'];
            // PRG pattern
            header("Location: data_barang.php?success=" . urlencode($result['message']));
            exit();
        } else {
            $error = $result['message'];
        }
    }
}

// Proses update barang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    if (!validate_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
    } else {
        $result = update_barang(
            $conn,
            $_POST['id'],
            $_POST['kode'],
            $_POST['nama'],
            $_POST['kategori'],
            $_POST['harga'],
            $_POST['stok']
        );
        
        if ($result['success']) {
            $success = $result['message'];
            // PRG pattern
            header("Location: data_barang.php?success=" . urlencode($result['message']));
            exit();
        } else {
            $error = $result['message'];
        }
    }
}

// Proses hapus barang
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $result = hapus_barang($conn, $_GET['id']);
    
    if ($result['success']) {
        header("Location: data_barang.php?success=" . urlencode($result['message']));
        exit();
    } else {
        $error = $result['message'];
    }
}

// Ambil pesan success dari URL (PRG pattern)
if (isset($_GET['success'])) {
    $success = $_GET['success'];
}

// Ambil data barang untuk edit
$edit_barang = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $edit_barang = get_barang_by_id($conn, $_GET['id']);
    if (!$edit_barang) {
        $error = 'Barang tidak ditemukan';
    }
}

// Ambil semua data barang
$barang_list = get_all_barang($conn);

// Generate CSRF token
$csrf_token = generate_csrf_token();

include 'includes/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Data Barang</h2>
        </div>
        <div class="col text-end">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                Tambah Barang
            </button>
        </div>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo clean_output($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo clean_output($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Total Nilai</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($barang_list) > 0): ?>
                            <?php foreach ($barang_list as $index => $barang): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo clean_output($barang['kode']); ?></td>
                                    <td><?php echo clean_output($barang['nama']); ?></td>
                                    <td><?php echo clean_output($barang['kategori']); ?></td>
                                    <td>Rp <?php echo number_format($barang['harga'], 0, ',', '.'); ?></td>
                                    <td><?php echo number_format($barang['stok']); ?></td>
                                    <td>Rp <?php echo number_format($barang['harga'] * $barang['stok'], 0, ',', '.'); ?></td>
                                    <td class="action-buttons">
                                        <a href="data_barang.php?action=edit&id=<?php echo $barang['id']; ?>" 
                                           class="btn btn-sm btn-warning">Edit</a>
                                        <button onclick="confirmDelete(<?php echo $barang['id']; ?>)" 
                                                class="btn btn-sm btn-danger">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center">Belum ada data barang</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Barang -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Barang</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="tambah">
                    <input type="hidden" name="csrf_token" value="<?php echo clean_output($csrf_token); ?>">
                    
                    <div class="mb-3">
                        <label for="kode" class="form-label">Kode Barang</label>
                        <input type="text" class="form-control" id="kode" name="kode" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" class="form-control" id="kategori" name="kategori" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <input type="number" class="form-control" id="harga" name="harga" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" min="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Barang -->
<?php if ($edit_barang): ?>
<div class="modal fade show" id="modalEdit" tabindex="-1" style="display: block;" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Barang</h5>
                <a href="data_barang.php" class="btn-close"></a>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="id" value="<?php echo $edit_barang['id']; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo clean_output($csrf_token); ?>">
                    
                    <div class="mb-3">
                        <label for="kode_edit" class="form-label">Kode Barang</label>
                        <input type="text" class="form-control" id="kode_edit" name="kode" 
                               value="<?php echo clean_output($edit_barang['kode']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nama_edit" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama_edit" name="nama" 
                               value="<?php echo clean_output($edit_barang['nama']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="kategori_edit" class="form-label">Kategori</label>
                        <input type="text" class="form-control" id="kategori_edit" name="kategori" 
                               value="<?php echo clean_output($edit_barang['kategori']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="harga_edit" class="form-label">Harga</label>
                        <input type="number" class="form-control" id="harga_edit" name="harga" 
                               value="<?php echo $edit_barang['harga']; ?>" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="stok_edit" class="form-label">Stok</label>
                        <input type="number" class="form-control" id="stok_edit" name="stok" 
                               value="<?php echo $edit_barang['stok']; ?>" min="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="data_barang.php" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal-backdrop fade show"></div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
