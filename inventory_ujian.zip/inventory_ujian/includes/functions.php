<?php
// Fungsi-fungsi untuk operasi CRUD dan validasi

// Fungsi untuk registrasi user
function register_user($conn, $username, $password, $nama_lengkap) {
    $username = validate_input($username);
    $nama_lengkap = validate_input($nama_lengkap);
    
    // Validasi input kosong
    if (empty($username) || empty($password) || empty($nama_lengkap)) {
        return ['success' => false, 'message' => 'Semua field harus diisi'];
    }
    
    // Validasi panjang username
    if (strlen($username) < 4 || strlen($username) > 50) {
        return ['success' => false, 'message' => 'Username harus 4-50 karakter'];
    }
    
    // Validasi panjang password
    if (strlen($password) < 6) {
        return ['success' => false, 'message' => 'Password minimal 6 karakter'];
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepared statement untuk insert
    $stmt = $conn->prepare("INSERT INTO users (username, password, nama_lengkap) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $hashed_password, $nama_lengkap);
    
    try {
        $stmt->execute();
        $stmt->close();
        return ['success' => true, 'message' => 'Registrasi berhasil'];
    } catch (Exception $e) {
        if ($conn->errno === 1062) {
            return ['success' => false, 'message' => 'Username sudah digunakan'];
        }
        return ['success' => false, 'message' => 'Terjadi kesalahan saat registrasi'];
    }
}

// Fungsi untuk login user
function login_user($conn, $username, $password) {
    $username = validate_input($username);
    
    if (empty($username) || empty($password)) {
        return ['success' => false, 'message' => 'Username dan password harus diisi'];
    }
    
    // Prepared statement untuk select
    $stmt = $conn->prepare("SELECT id, username, password, nama_lengkap FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['logged_in'] = true;
            
            $stmt->close();
            return ['success' => true, 'message' => 'Login berhasil'];
        }
    }
    
    $stmt->close();
    return ['success' => false, 'message' => 'Username atau password salah'];
}

// Fungsi untuk cek login
function check_login() {
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header("Location: login.php");
        exit();
    }
}

// Fungsi untuk tambah barang
function tambah_barang($conn, $kode, $nama, $kategori, $harga, $stok) {
    $kode = validate_input($kode);
    $nama = validate_input($nama);
    $kategori = validate_input($kategori);
    
    // Validasi input kosong
    if (empty($kode) || empty($nama) || empty($kategori) || empty($harga) || empty($stok)) {
        return ['success' => false, 'message' => 'Semua field harus diisi'];
    }
    
    // Validasi numerik
    if (!is_numeric($harga) || !is_numeric($stok)) {
        return ['success' => false, 'message' => 'Harga dan stok harus berupa angka'];
    }
    
    // Validasi nilai negatif
    if ($harga < 0 || $stok < 0) {
        return ['success' => false, 'message' => 'Harga dan stok tidak boleh negatif'];
    }
    
    // Prepared statement untuk insert
    $stmt = $conn->prepare("INSERT INTO barang (kode, nama, kategori, harga, stok) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdi", $kode, $nama, $kategori, $harga, $stok);
    
    try {
        $stmt->execute();
        $stmt->close();
        return ['success' => true, 'message' => 'Barang berhasil ditambahkan'];
    } catch (Exception $e) {
        if ($conn->errno === 1062) {
            return ['success' => false, 'message' => 'Kode barang sudah ada'];
        }
        return ['success' => false, 'message' => 'Terjadi kesalahan saat menambah barang'];
    }
}

// Fungsi untuk update barang
function update_barang($conn, $id, $kode, $nama, $kategori, $harga, $stok) {
    $kode = validate_input($kode);
    $nama = validate_input($nama);
    $kategori = validate_input($kategori);
    
    // Validasi ID
    if (!is_numeric($id) || $id <= 0) {
        return ['success' => false, 'message' => 'ID barang tidak valid'];
    }
    
    // Validasi input kosong
    if (empty($kode) || empty($nama) || empty($kategori) || empty($harga) || empty($stok)) {
        return ['success' => false, 'message' => 'Semua field harus diisi'];
    }
    
    // Validasi numerik
    if (!is_numeric($harga) || !is_numeric($stok)) {
        return ['success' => false, 'message' => 'Harga dan stok harus berupa angka'];
    }
    
    // Validasi nilai negatif
    if ($harga < 0 || $stok < 0) {
        return ['success' => false, 'message' => 'Harga dan stok tidak boleh negatif'];
    }
    
    // Cek apakah barang ada
    $stmt_check = $conn->prepare("SELECT id FROM barang WHERE id = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows === 0) {
        $stmt_check->close();
        return ['success' => false, 'message' => 'Barang tidak ditemukan'];
    }
    $stmt_check->close();
    
    // Prepared statement untuk update
    $stmt = $conn->prepare("UPDATE barang SET kode = ?, nama = ?, kategori = ?, harga = ?, stok = ? WHERE id = ?");
    $stmt->bind_param("sssdii", $kode, $nama, $kategori, $harga, $stok, $id);
    
    try {
        $stmt->execute();
        $stmt->close();
        return ['success' => true, 'message' => 'Barang berhasil diupdate'];
    } catch (Exception $e) {
        if ($conn->errno === 1062) {
            return ['success' => false, 'message' => 'Kode barang sudah digunakan'];
        }
        return ['success' => false, 'message' => 'Terjadi kesalahan saat update barang'];
    }
}

// Fungsi untuk hapus barang
function hapus_barang($conn, $id) {
    // Validasi ID
    if (!is_numeric($id) || $id <= 0) {
        return ['success' => false, 'message' => 'ID barang tidak valid'];
    }
    
    // Cek apakah barang ada
    $stmt_check = $conn->prepare("SELECT id FROM barang WHERE id = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows === 0) {
        $stmt_check->close();
        return ['success' => false, 'message' => 'Barang tidak ditemukan'];
    }
    $stmt_check->close();
    
    // Prepared statement untuk delete
    $stmt = $conn->prepare("DELETE FROM barang WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    try {
        $stmt->execute();
        $stmt->close();
        return ['success' => true, 'message' => 'Barang berhasil dihapus'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Terjadi kesalahan saat menghapus barang'];
    }
}

// Fungsi untuk get barang by ID
function get_barang_by_id($conn, $id) {
    // Validasi ID
    if (!is_numeric($id) || $id <= 0) {
        return null;
    }
    
    $stmt = $conn->prepare("SELECT * FROM barang WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $barang = $result->fetch_assoc();
        $stmt->close();
        return $barang;
    }
    
    $stmt->close();
    return null;
}

// Fungsi untuk get semua barang
function get_all_barang($conn) {
    $stmt = $conn->prepare("SELECT * FROM barang ORDER BY created_at DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    $barang_list = [];
    
    while ($row = $result->fetch_assoc()) {
        $barang_list[] = $row;
    }
    
    $stmt->close();
    return $barang_list;
}

// Fungsi untuk hitung total barang
function hitung_total_barang($conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM barang");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['total'];
}

// Fungsi untuk hitung total stok
function hitung_total_stok($conn) {
    $stmt = $conn->prepare("SELECT SUM(stok) as total FROM barang");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['total'] ?? 0;
}

// Fungsi untuk hitung total nilai
function hitung_total_nilai($conn) {
    $stmt = $conn->prepare("SELECT SUM(harga * stok) as total FROM barang");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['total'] ?? 0;
}
?>
