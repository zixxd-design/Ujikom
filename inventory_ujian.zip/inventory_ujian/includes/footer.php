</main>

<!-- Footer -->
<footer class="footer text-center">
    <div class="container">
        <p class="mb-0">&copy; 2024 Sistem Inventory Ujian - Junior Web Developer</p>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS untuk konfirmasi hapus -->
<script>
function confirmDelete(id) {
    if (confirm('Apakah Anda yakin ingin menghapus barang ini?')) {
        window.location.href = 'data_barang.php?action=delete&id=' + id;
    }
}
</script>

</body>
</html>
