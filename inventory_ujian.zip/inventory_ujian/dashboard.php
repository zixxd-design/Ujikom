<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

// Cek login
check_login();

$page_title = 'Dashboard';

// Ambil statistik
$total_barang = hitung_total_barang($conn);
$total_stok = hitung_total_stok($conn);
$total_nilai = hitung_total_nilai($conn);

include 'includes/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2 style="color: var(--primary-color); font-weight: 700;">Dashboard</h2>
            <p class="text-muted">Selamat datang, <strong><?php echo clean_output($_SESSION['nama_lengkap']); ?></strong></p>
        </div>
    </div>
    
    <div class="row">
        <!-- Card Total Barang -->
        <div class="col-md-4 mb-4">
            <div class="card stat-card border-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="stat-label mb-1">Jumlah Barang</p>
                            <h3 class="stat-number mb-0"><?php echo number_format($total_barang); ?></h3>
                            <small class="text-muted">Total jenis barang</small>
                        </div>
                        <div class="stat-icon" style="color: var(--primary-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M2.5 3.5a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-11zm2-2a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1h-7zM0 13a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 16 13V6a1.5 1.5 0 0 0-1.5-1.5h-13A1.5 1.5 0 0 0 0 6v7zm1.5.5A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-13z"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card Total Stok -->
        <div class="col-md-4 mb-4">
            <div class="card stat-card border-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="stat-label mb-1">Total Stok</p>
                            <h3 class="stat-number mb-0" style="color: var(--success-color);"><?php echo number_format($total_stok); ?></h3>
                            <small class="text-muted">Unit tersedia</small>
                        </div>
                        <div class="stat-icon" style="color: var(--success-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5 8 5.961 14.154 3.5 8.186 1.113zM15 4.239l-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Card Total Nilai -->
        <div class="col-md-4 mb-4">
            <div class="card stat-card border-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="stat-label mb-1">Total Nilai</p>
                            <h3 class="stat-number mb-0" style="color: var(--warning-color);">Rp <?php echo number_format($total_nilai, 0, ',', '.'); ?></h3>
                            <small class="text-muted">Nilai inventory</small>
                        </div>
                        <div class="stat-icon" style="color: var(--warning-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Informasi Sistem</h5>
                </div>
                <div class="card-body">
                    <div class="info-box">
                        <h6 style="color: var(--primary-color); font-weight: 700;">Fitur Sistem Inventory</h6>
                        <p class="mb-2">Sistem ini menyediakan fitur lengkap untuk manajemen inventory:</p>
                        <ul class="mb-3">
                            <li><strong>Manajemen Data Barang</strong> - Tambah, edit, dan hapus data barang dengan mudah</li>
                            <li><strong>Dashboard Statistik</strong> - Monitor jumlah barang, stok, dan nilai inventory secara realtime</li>
                            <li><strong>Laporan PDF</strong> - Generate laporan inventory dalam format PDF untuk dokumentasi</li>
                            <li><strong>Keamanan Terjamin</strong> - Sistem dilengkapi dengan proteksi session, CSRF token, dan enkripsi password</li>
                        </ul>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="data_barang.php" class="btn btn-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="me-1" viewBox="0 0 16 16">
                                    <path d="M2.5 3.5a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-11zm2-2a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1h-7zM0 13a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 16 13V6a1.5 1.5 0 0 0-1.5-1.5h-13A1.5 1.5 0 0 0 0 6v7zm1.5.5A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-13z"/>
                                </svg>
                                Kelola Data Barang
                            </a>
                            <a href="laporan.php" class="btn btn-success">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="me-1" viewBox="0 0 16 16">
                                    <path d="M8.5 2.687c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/>
                                </svg>
                                Lihat Laporan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
