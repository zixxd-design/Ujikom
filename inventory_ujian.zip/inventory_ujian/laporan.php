<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

// Cek login
check_login();

$page_title = 'Laporan Inventory';

// Ambil data barang
$barang_list = get_all_barang($conn);

// Ambil statistik
$total_barang = hitung_total_barang($conn);
$total_stok = hitung_total_stok($conn);
$total_nilai = hitung_total_nilai($conn);

include 'includes/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Laporan Inventory</h2>
        </div>
        <div class="col text-end">
            <a href="cetak_pdf.php" target="_blank" class="btn btn-danger">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
                    <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z"/>
                    <path d="M4.603 12.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 1.482-.645 19.701 19.701 0 0 0 1.062-2.227 7.269 7.269 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a10.954 10.954 0 0 0 .98 1.686 5.753 5.753 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.856.856 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.716 5.716 0 0 1-.911-.95 11.642 11.642 0 0 0-1.997.406 11.311 11.311 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.793.793 0 0 1-.58.029zm1.379-1.901c-.166.076-.32.156-.459.238-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361.01.022.02.036.026.044a.27.27 0 0 0 .035-.012c.137-.056.355-.235.635-.572a8.18 8.18 0 0 0 .45-.606zm1.64-1.33a12.647 12.647 0 0 1 1.01-.193 11.666 11.666 0 0 1-.51-.858 20.741 20.741 0 0 1-.5 1.05zm2.446.45c.15.162.296.3.435.41.24.19.407.253.498.256a.107.107 0 0 0 .07-.015.307.307 0 0 0 .094-.125.436.436 0 0 0 .059-.2.095.095 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a3.881 3.881 0 0 0-.612-.053zM8.078 5.8a6.7 6.7 0 0 0 .2-.828c.031-.188.043-.343.038-.465a.613.613 0 0 0-.032-.198.517.517 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822.024.111.054.227.09.346z"/>
                </svg>
                Cetak PDF
            </a>
        </div>
    </div>
    
    <!-- Statistik -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="text-muted">Total Barang</h6>
                    <h3 class="text-primary"><?php echo number_format($total_barang); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="text-muted">Total Stok</h6>
                    <h3 class="text-success"><?php echo number_format($total_stok); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6 class="text-muted">Total Nilai Inventory</h6>
                    <h3 class="text-warning">Rp <?php echo number_format($total_nilai, 0, ',', '.'); ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tabel Data Barang -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Detail Data Barang</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Total Nilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($barang_list) > 0): ?>
                            <?php foreach ($barang_list as $index => $barang): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo clean_output($barang['kode']); ?></td>
                                    <td><?php echo clean_output($barang['nama']); ?></td>
                                    <td><?php echo clean_output($barang['kategori']); ?></td>
                                    <td class="text-end">Rp <?php echo number_format($barang['harga'], 0, ',', '.'); ?></td>
                                    <td class="text-center"><?php echo number_format($barang['stok']); ?></td>
                                    <td class="text-end">Rp <?php echo number_format($barang['harga'] * $barang['stok'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="table-secondary fw-bold">
                                <td colspan="5" class="text-end">Total:</td>
                                <td class="text-center"><?php echo number_format($total_stok); ?></td>
                                <td class="text-end">Rp <?php echo number_format($total_nilai, 0, ',', '.'); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">Belum ada data barang</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
