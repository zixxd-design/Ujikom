# SISTEM INVENTORY UJIAN - JUNIOR WEB DEVELOPER

Aplikasi CRUD inventory barang dengan PHP native dan MySQL - Navy Theme.

## FITUR
- Registrasi dan Login user
- Dashboard dengan statistik (jumlah barang, total stok, total nilai)
- Data barang (CRUD: tambah, edit, hapus)
- Laporan inventory dengan cetak PDF
- Proteksi session dan CSRF token
- Mobile responsive dengan Bootstrap 5
- Design tema Navy yang profesional

## TEKNOLOGI
- PHP 7.4+ (Native, no framework)
- MySQL (Database: ujian)
- Bootstrap 5.3.0 (CDN)
- FPDF (PDF generation)

## CARA INSTALASI

1. Database sudah diimport otomatis: ujian

2. Akses aplikasi:
   - Buka browser: http://localhost/inventory_ujian
   - Registrasi akun baru
   - Login dan mulai gunakan

## PERBEDAAN DENGAN INVENTORY_SYSTEM
- Database: ujian (bukan inventory_db)
- Design: Navy theme dengan gradient
- Warna utama: Navy Blue (#1e3a5f)
- UI lebih modern dengan shadow dan animasi
- Icon SVG di navbar dan dashboard

## KEAMANAN
- Password Hash (bcrypt)
- Prepared Statement (SQL injection prevention)
- CSRF Token Protection
- XSS Protection (htmlspecialchars)
- Session Security

## URL
http://localhost/inventory_ujian
